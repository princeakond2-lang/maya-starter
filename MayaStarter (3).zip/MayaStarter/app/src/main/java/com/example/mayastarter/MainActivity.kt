package com.example.mayastarter

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.View
import android.view.animation.AnimationUtils
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.Locale

/**
 * MAYA STARTER
 * ------------
 * A minimal example: press the mic, speak Bangla, the app sends your
 * words to Google's Gemini API and speaks the answer back.
 *
 * BEFORE RUNNING:
 * 1. Get a free Gemini API key from Google AI Studio (aistudio.google.com).
 * 2. Paste it into GEMINI_API_KEY below.
 * NEVER ship a real app with the key hardcoded like this — for anything
 * beyond your own testing, call Gemini from a small backend server you
 * control, so the key isn't sitting inside the APK where it can be
 * extracted and abused by other people.
 */
class MainActivity : AppCompatActivity() {

    // TODO: paste your own free key from https://aistudio.google.com
    private val GEMINI_API_KEY = "AQ.Ab8RN6L9GmxsNzoeMoJvoROrkONREJi4A31n5K_0I9YsO_i38w"
    private val GEMINI_MODEL = "gemini-2.0-flash"

    private lateinit var conversationText: TextView
    private lateinit var micButton: Button
    private lateinit var orbCore: View
    private lateinit var orbRing: View
    private lateinit var statusText: TextView
    private lateinit var speechRecognizer: SpeechRecognizer
    private lateinit var tts: TextToSpeech
    private val client = OkHttpClient()

    private val micPermissionRequest = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        conversationText = findViewById(R.id.conversationText)
        micButton = findViewById(R.id.micButton)
        orbCore = findViewById(R.id.orbCore)
        orbRing = findViewById(R.id.orbRing)
        statusText = findViewById(R.id.statusText)

        startIdleOrbAnimation()

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts.language = Locale("bn", "BD")
            }
        }
        tts.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                runOnUiThread {
                    startIdleOrbAnimation()
                    statusText.text = "বলতে মাইকে চাপুন"
                }
            }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {}
        })

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)

        micButton.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this, arrayOf(Manifest.permission.RECORD_AUDIO), micPermissionRequest
                )
            } else {
                startListening()
            }
        }
    }

    /** Slow "breathing" pulse + slow rotation — the resting state. */
    private fun startIdleOrbAnimation() {
        orbCore.clearAnimation()
        orbCore.startAnimation(AnimationUtils.loadAnimation(this, R.anim.orb_pulse))
        orbRing.startAnimation(AnimationUtils.loadAnimation(this, R.anim.orb_rotate))
    }

    /** Faster pulse — used while listening to you or while Maya is speaking. */
    private fun startActiveOrbAnimation() {
        orbCore.clearAnimation()
        orbCore.startAnimation(AnimationUtils.loadAnimation(this, R.anim.orb_pulse_fast))
    }

    private fun startListening() {
        statusText.text = "শুনছি..."
        startActiveOrbAnimation()

        val intent = android.content.Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
        }

        speechRecognizer.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle) {
                val matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val spokenText = matches?.firstOrNull()
                if (spokenText == null) {
                    startIdleOrbAnimation()
                    statusText.text = "বলতে মাইকে চাপুন"
                    return
                }
                appendLine("আপনি: $spokenText")
                statusText.text = "ভাবছি..."
                askGemini(spokenText)
            }

            override fun onError(error: Int) {
                appendLine("(শুনতে সমস্যা হয়েছে, আবার চেষ্টা করুন)")
                statusText.text = "বলতে মাইকে চাপুন"
                startIdleOrbAnimation()
            }

            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        speechRecognizer.startListening(intent)
    }

    private fun askGemini(userText: String) {
        if (GEMINI_API_KEY == "PASTE_YOUR_GEMINI_API_KEY_HERE") {
            appendLine("(এখনো API key বসানো হয়নি — MainActivity.kt ফাইলে GEMINI_API_KEY বসান)")
            return
        }

        val url =
            "https://generativelanguage.googleapis.com/v1beta/models/$GEMINI_MODEL:generateContent?key=$GEMINI_API_KEY"

        val body = JSONObject().apply {
            put("contents", JSONArray().put(
                JSONObject().put("parts", JSONArray().put(
                    JSONObject().put("text", userText)
                ))
            ))
        }

        val request = Request.Builder()
            .url(url)
            .post(RequestBody.create(MediaType.parse("application/json"), body.toString()))
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    appendLine("(নেটওয়ার্ক সমস্যা: ${e.message})")
                    statusText.text = "বলতে মাইকে চাপুন"
                    startIdleOrbAnimation()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val raw = response.body()?.string() ?: ""
                val reply = try {
                    JSONObject(raw)
                        .getJSONArray("candidates")
                        .getJSONObject(0)
                        .getJSONObject("content")
                        .getJSONArray("parts")
                        .getJSONObject(0)
                        .getString("text")
                } catch (e: Exception) {
                    "(উত্তর পড়তে সমস্যা হয়েছে: $raw)"
                }

                runOnUiThread {
                    appendLine("Maya: $reply")
                    statusText.text = "বলছে..."
                    startActiveOrbAnimation()
                    tts.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "maya_reply")
                }
            }
        })
    }

    private fun appendLine(text: String) {
        conversationText.text = "${conversationText.text}\n\n$text"
    }

    override fun onDestroy() {
        speechRecognizer.destroy()
        tts.shutdown()
        super.onDestroy()
    }
}
